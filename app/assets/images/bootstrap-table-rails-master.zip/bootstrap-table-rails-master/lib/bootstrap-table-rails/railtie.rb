module Bootstrap
  module Table
    module Rails
      class Railtie < ::Rails::Railtie; end
    end
  end
end
