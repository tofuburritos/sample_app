module Bootstrap
  module Table
    module Rails
      VERSION = "1.10.1"
    end
  end
end
