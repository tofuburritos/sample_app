module Bootstrap
  module Table
    module Rails
      class Engine < ::Rails::Engine
      end
    end
  end
end
